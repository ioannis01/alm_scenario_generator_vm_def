# ALM Scenario Generator - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Prerequisites

1. **Python 3.8+** installed
2. **Ollama** running with Llama 3 model

### Step 1: Install Ollama (if not installed)

```bash
# Download from https://ollama.ai/
# Or on Linux:
curl -fsSL https://ollama.com/install.sh | sh

# Start Ollama
ollama serve

# Pull Llama 3 model (in another terminal)
ollama pull llama3
```

### Step 2: Install Python Dependencies

```bash
pip install flask pandas requests pyodbc
```

### Step 3: Test the Package

```bash
cd /mnt/user-data/outputs

# Quick import test
python3 << 'EOF'
from alm_scenarios import ALMScenarioGenerator, LlamaClient
from alm_scenarios.utils import create_sample_universe

print("✓ Package imports successful!")

# Test data creation
risk_factors, counterparties, contracts = create_sample_universe()
print(f"✓ Created {len(risk_factors)} risk factors")
print(f"✓ Created {len(counterparties)} counterparties")
print(f"✓ Created {len(contracts)} contracts")

print("\n🎉 Everything is working!")
EOF
```

### Step 4: Run the Web Interface

```bash
# Start the web server
python3 web_interface_enhanced.py
```

Then open your browser to:
- Local: `http://localhost:8081`
- Network: `http://YOUR_IP:8081`

### Step 5: Generate Your First Scenario

1. **Enter an instruction** like:
   ```
   Generate 3 severe stress scenarios with +200 bps interest rate shock
   and credit spread widening
   ```

2. **Set parameters:**
   - Number of scenarios: 3
   - Scenario type: Stress

3. **Click "Generate Scenarios"**

4. **View results:**
   - Interactive charts
   - Detailed shock breakdown
   - Export to CSV

---

## 📝 Example Usage (Python)

```python
from alm_scenarios import ALMScenarioGenerator, LlamaClient
from alm_scenarios.utils import create_sample_universe

# 1. Create sample data
risk_factors, counterparties, contracts = create_sample_universe()

# 2. Initialize LLM client
llm_client = LlamaClient(
    base_url="http://localhost:11434",
    model_name="llama3"
)

# 3. Create scenario generator
generator = ALMScenarioGenerator(llm_client)

# 4. Generate scenarios
scenarios, df = generator.generate_scenarios(
    risk_factors=risk_factors,
    counterparties=counterparties,
    contracts=contracts,
    user_instruction="Create 3 stress scenarios for recession",
    num_scenarios=3,
    scenario_type="stress"
)

# 5. View results
for i, scenario in enumerate(scenarios, 1):
    print(f"\nScenario {i}: {scenario.name}")
    print(f"Description: {scenario.description}")
    print(f"Number of shocks: {len(scenario.shocks)}")

# 6. Export to CSV
df.to_csv("my_scenarios.csv", index=False)
print(f"\n✓ Saved {len(scenarios)} scenarios to my_scenarios.csv")
```

---

## 🔧 Troubleshooting

### "Cannot connect to Ollama"

**Solution:**
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# If not running, start it:
ollama serve
```

### "Model 'llama3' not found"

**Solution:**
```bash
# Pull the model
ollama pull llama3

# Verify it's available
ollama list
```

### "Import error: No module named 'alm_scenarios'"

**Solution:**
```bash
# Make sure you're in the right directory
cd /mnt/user-data/outputs

# Add to Python path
export PYTHONPATH="/mnt/user-data/outputs:$PYTHONPATH"

# Or run Python from the outputs directory
python3 your_script.py
```

### Web interface won't start

**Solution:**
```bash
# Check if port 8081 is already in use
lsof -i :8081

# Kill existing process if needed
kill -9 <PID>

# Or use a different port
# Edit web_interface_enhanced.py, change port=8081 to port=8082
```

---

## 📂 Project Structure

```
/mnt/user-data/outputs/
├── alm_scenarios/              # Main package
│   ├── __init__.py
│   ├── scenario_generator.py
│   ├── models/
│   ├── llm/
│   ├── parsers/
│   └── utils/
│
├── web_interface_enhanced.py   # Web UI
├── load_alm_data.py           # Data loader
├── xml_loader_dynamic.py      # XML parser
├── scenario_api.py            # REST API
│
└── Documentation/
    ├── PACKAGE_COMPLETE.md    # Complete guide
    ├── ANALYSIS.md            # Technical analysis
    └── QUICK_START.md         # This file
```

---

## 🎯 What You Can Do Now

### ✅ Generate Scenarios
- Stress testing scenarios
- Stochastic scenarios
- Custom shock calibrations

### ✅ Use Multiple Data Sources
- RiskPro database
- XML files (drag & drop)
- Sample data generator

### ✅ Customize Prompts
- Modify system prompts
- Control shock magnitudes
- Specify economic narratives

### ✅ Export Results
- CSV files
- Pandas DataFrames
- JSON format

---

## 📚 Next Steps

1. **Try different instructions:**
   - "Model a currency crisis with CHF appreciation"
   - "Generate recession scenarios with rising unemployment"
   - "Create yield curve inversion scenarios"

2. **Load real data:**
   - Connect to RiskPro database
   - Upload XML files
   - Use your own risk factors

3. **Implement real valuations:**
   - Replace mock impact metrics
   - Add real NII calculations
   - Implement EVE and VaR

4. **Customize the UI:**
   - Modify colors and themes
   - Add new charts
   - Create custom reports

---

## 💡 Tips

- **Start simple:** Use sample data first before connecting to real databases
- **Test incrementally:** Generate 1-2 scenarios first, then scale up
- **Check Ollama logs:** If generation fails, check Ollama output for errors
- **Use specific instructions:** More specific = better quality scenarios
- **Save your work:** Export CSVs frequently

---

## 🆘 Need Help?

1. Check the documentation in `PACKAGE_COMPLETE.md`
2. Review the technical analysis in `ANALYSIS.md`
3. Look at example code in `scenario_generator.py`
4. Test imports and connections first

---

## ✅ Success Criteria

You'll know everything is working when:
- ✓ Import test passes without errors
- ✓ Web interface loads at http://localhost:8081
- ✓ Sample data generates successfully
- ✓ Scenarios can be generated and displayed
- ✓ CSV export works

**Happy scenario generation! 🚀**
